/**
 * Vercel serverless API for Otakudesu (simple scraper)
 * Default target site is read from environment variable OT_SITE. 
 * If not set, default is 'https://otakudesu.id' (you can change in Vercel env).
 *
 * Note: Selectors are generic and may require adjustments depending on site structure.
 * Each function uses a tiny in-memory cache to reduce repeated scraping.
 */


import { SITE, fetchHTML, parseHTML } from '../_helpers.js';

export default async function handler(req, res) {
  try {
    const { slug } = req.query;
    if(!slug) return res.status(400).json({ success: false, message: 'slug required' });
    const url = SITE + '/anime/' + slug;
    const html = await fetchHTML(url);
    const $ = parseHTML(html);

    const title = $('h1.entry-title, .post-title, .judul').first().text().trim();
    const synopsis = $('.sinopc, .sinopsis, .entry-content').first().text().trim();
    const image = $('.thumb img, .cover img, .post img').first().attr('src') || '';
    const genres = [];
    $('.genre a, .genres a, .tag a').each((i, el) => genres.push($(el).text().trim()));
    const episodes = [];
    // try multiple possible lists
    $('#episode_related a, .episode-list a, .eps a, .serv a, .last_episode a').each((i, el) => {
      const epTitle = $(el).text().trim();
      const epUrl = $(el).attr('href');
      episodes.push({ epTitle, epUrl });
    });
    // fallback: list items
    $('.eps-list li a, .episodelist li a').each((i, el) => {
      const epTitle = $(el).text().trim();
      const epUrl = $(el).attr('href');
      episodes.push({ epTitle, epUrl });
    });

    res.status(200).json({ success: true, data: { title, synopsis, image, genres, episodes } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to fetch anime detail', error: err.message });
  }
}
