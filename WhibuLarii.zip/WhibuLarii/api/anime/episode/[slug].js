/**
 * Vercel serverless API for Otakudesu (simple scraper)
 * Default target site is read from environment variable OT_SITE. 
 * If not set, default is 'https://otakudesu.id' (you can change in Vercel env).
 *
 * Note: Selectors are generic and may require adjustments depending on site structure.
 * Each function uses a tiny in-memory cache to reduce repeated scraping.
 */


import { SITE, fetchHTML, parseHTML } from '../_helpers.js';

export default async function handler(req, res) {
  try {
    const { slug } = req.query;
    if(!slug) return res.status(400).json({ success: false, message: 'slug required' });
    const url = slug.startsWith('http') ? slug : (SITE + '/' + slug);
    const html = await fetchHTML(url);
    const $ = parseHTML(html);
    // many sites include a reader script or images inside .post-content
    const images = [];
    // common selectors
    $('.post-content img, .read-content img, .entry img, .chimg img').each((i, el) => {
      const src = $(el).attr('src') || $(el).attr('data-src') || $(el).attr('data-lazy-src');
      if(src) images.push(src);
    });

    // fallback: look for scripts containing ts_reader or JSON
    if(images.length === 0){
      const scripts = $('script').map((i, s) => $(s).html()).get().join('\n');
      const m = scripts.match(/(ts_reader\.run\(|\"images\"\s*:\s*\[)/);
      if(m){
        // attempt to extract JSON array of images
        const arrMatch = scripts.match(/(images\s*:\s*\[(?:.|\n)*?\])/);
        if(arrMatch){
          try{
            const jsonStr = '{' + arrMatch[0] + '}';
            const obj = JSON.parse(jsonStr.replace(/([a-zA-Z0-9_]+)\s*:/g, '"$1":'));
            if(obj.images && Array.isArray(obj.images)) images.push(...obj.images);
          }catch(e){}
        }
      }
    }

    res.status(200).json({ success: true, images });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: 'Failed to fetch episode', error: err.message });
  }
}
